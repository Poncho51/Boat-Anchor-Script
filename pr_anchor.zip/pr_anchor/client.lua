RequestStreamedTextureDict("anchorNotifications", 1) -- Do not delete


local ped = PlayerPedId()
local vehicle = GetVehiclePedIsIn(ped)

local nIcon = Config.NotificationIcon
local nTime = Config.NotificationTime

------------[Notifications]------------
function sendNotification(subject, textureDict, textureName, color)
    if Config.NotificationType == "ox_lib" then
        lib.notify({
            title = 'Anchor',
            description = subject,
            duration = nTime,
            position = 'top',
            style = {
                backgroundColor = '#141517',
                color = '#C1C2C5',
                ['.description'] = { color = '#909296' }
            },
            type = 'success'
        })

    else
        BeginTextCommandThefeedPost("Anchor:Notification")
        AddTextComponentSubstringPlayerName(subject)
        ThefeedSetNextPostBackgroundColor(color)
        EndTextCommandThefeedPostMessagetext(textureDict, textureName, false, 4, "Anchor", subject)
        EndTextCommandThefeedPostTicker(true, false)
    end
end


function sendErrorNotification(subject, textureDict, textureName, color)
    if Config.NotificationType == "ox_lib" then
        lib.notify({
            title = 'Anchor',
            description = subject,
            duration = nTime,
            position = 'top',
            style = {
                backgroundColor = '#141517',
                color = '#C1C2C5',
                ['.description'] = { color = '#909296' }
            },
            icon = 'ban',
            iconColor = '#C53030'
        })
    else
        BeginTextCommandThefeedPost("Anchor:Notification")
        AddTextComponentSubstringPlayerName(subject)
        ThefeedSetNextPostBackgroundColor(color)
        EndTextCommandThefeedPostMessagetext(textureDict, textureName, false, 4, "Anchor", subject)
        EndTextCommandThefeedPostTicker(true, false)

    end
end

------------[Functions]------------

-- Function to notify the player when they are not in a boat
local function notaboat()
    if Config.NotifyWith[1] == "notifications" then
        sendErrorNotification(Config.NotificationMessages[6], "anchorNotifications", nIcon, 161)
        Wait(nTime)
        ThefeedRemoveItem()
    elseif Config.NotifyWith[1] == "messages" then
        TriggerEvent('chat:addMessage', {args = {Config.ChatMessages[6]}})
    end
end

-- Function to notify the player when they are not the driver
local function notdriver()
    if Config.NotifyWith[1] == "notifications" then
        sendErrorNotification(Config.NotificationMessages[5], "anchorNotifications", nIcon, 161)
        Wait(nTime)
        ThefeedRemoveItem()
    elseif Config.NotifyWith[1] == "messages" then
        TriggerEvent('chat:addMessage', {args = {Config.ChatMessages[5]}})
    end
end

-- Function to anchor the boat
local function anchorOn()
    PlaySoundFromEntity(GetSoundId(), "BODY_FALL_DIVE_WATER_MASTER", vehicle, 0, 0, 0)
    Wait(400)
    SetBoatAnchor(vehicle, true)
    SetBoatFrozenWhenAnchored(vehicle, true)

    if Config.NotifyWith[1] == "notifications" then
        sendNotification(Config.NotificationMessages[1], "anchorNotifications", nIcon, 161)
        Wait(nTime)
        ThefeedRemoveItem()
    elseif Config.NotifyWith[1] == "messages" then
        TriggerEvent('chat:addMessage', {args = {Config.ChatMessages[1]}})
    end
end

-- Function to unanchor the boat
local function anchorOff()
    PlaySoundFromEntity(GetSoundId(), "UNDER_WATER_COME_UP", vehicle, 0, 0, 0)
    Wait(400)
    SetBoatAnchor(vehicle, false)
    SetBoatFrozenWhenAnchored(vehicle, false)

    if Config.NotifyWith[1] == "notifications" then
        sendNotification(Config.NotificationMessages[2], "anchorNotifications", nIcon, 161)
        Wait(nTime)
        ThefeedRemoveItem()
    elseif Config.NotifyWith[1] == "messages" then
        TriggerEvent('chat:addMessage', {args = {Config.ChatMessages[2]}})
    end
end

-- Function to notify if the player is moving too fast to drop the anchor
local function tooFast()
    if Config.NotifyWith[1] == "notifications" then
        sendErrorNotification(Config.NotificationMessages[3], "anchorNotifications", nIcon, 161)
        Wait(nTime)
        ThefeedRemoveItem()
    elseif Config.NotifyWith[1] == "messages" then
        TriggerEvent('chat:addMessage', {args = {Config.ChatMessages[3]}})
    end
end

-- Function to notify if the anchor has broken
local function anchorBreak()
    PlaySoundFromEntity(GetSoundId(), "UNDER_WATER_COME_UP", vehicle, 0, 0, 0)
    SetBoatAnchor(vehicle, false)
    SetBoatFrozenWhenAnchored(vehicle, false)

    if Config.NotifyWith[1] == "notifications" then
        sendErrorNotification(Config.NotificationMessages[4], "anchorNotifications", nIcon, 161)
        Wait(nTime)
        ThefeedRemoveItem()
    elseif Config.NotifyWith[1] == "messages" then
        TriggerEvent('chat:addMessage', {args = {Config.ChatMessages[4]}})
    end
end

-- Function to check if the vehicle is in the allowed vehicles list
local function isAllowedVehicle(model)
    for _, allowedVehicle in ipairs(Config.AllowedVehicles) do
        if model == GetHashKey(allowedVehicle) then
            return true
        end
    end
    return false
end

------------[Command]------------
RegisterCommand('anchor', function()
    local ped = PlayerPedId()
    local vehicle = GetVehiclePedIsIn(ped)
    local model = GetEntityModel(vehicle)
    local boat = IsThisModelABoat(model)
    local mph = GetEntitySpeed(vehicle) * 2.23694
    local inWater = IsEntityInWater(vehicle)

    if not boat and not isAllowedVehicle(model) then
        if Config.NotifyNotInBoat then
            notaboat()
        end
        return
    end

    if not inWater then
        return
    end

    if GetPedInVehicleSeat(vehicle, -1) ~= ped then
        if not Config.CanPassengerAnchor then
            notdriver()
            return
        end
    end

    if mph > Config.MaxSpeed then
        tooFast()
        return
    end

    if IsBoatAnchoredAndFrozen(vehicle) then
        anchorOff()
    else
        anchorOn()
    end
end)

------------[Breaking the anchor]------------
CreateThread(function()
    while true do
        Wait(200)

        ped = PlayerPedId()
        vehicle = GetVehiclePedIsIn(ped)
        local model = GetEntityModel(vehicle)
        local boat = IsThisModelABoat(model)
        local mph = GetEntitySpeed(vehicle) * 2.23694
        local inWater = IsEntityInWater(vehicle)

        if not boat then
            return
        end

        if not inWater then
            return
        end

        local rpm = GetVehicleCurrentRpm(vehicle)

        if Config.CanAnchorBreak and IsBoatAnchoredAndFrozen(vehicle) then
            if rpm > 0.400 and mph > 2.5 then
                anchorBreak()
                print('Anchor broke due to high RPM')
            end
        end
    end
end)

-- Key mapping
RegisterKeyMapping('anchor', 'Drop/Pick up the anchor', 'keyboard', 'i')