-- Poncho's Resources Boat Anchor Version 2.1

Author 'Poncho'
Description 'Fully configurable anchor script with ox_lib notification support.'
Version '2.1'

------------------------------

fx_version 'cerulean'
game       'gta5'
lua54 'yes'


client_scripts {
    'client.lua'
}

shared_scripts {
    '@ox_lib/init.lua', -- Comment this if you aren't using ox_lib
    'config.lua'
}