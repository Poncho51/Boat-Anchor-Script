Config = {}

-- Determines how the player is notified when using the anchor command.
-- "notifications" - Sends a notification
-- "messages"      - Sends a message in chat
Config.NotifyWith = { 
    "notifications" 
}

-- Determines the type of notifications to use.
-- "ox_lib" - Uses ox_lib notifications
-- "normal" - Uses standard GTA notifications
Config.NotificationType = "normal"

-- Sets the icon to be used in notifications.
-- "blue"
-- "black"
-- "beach"
-- See the "icons" folder for models.
-- Note: This does not apply to ox_lib notifications.
Config.NotificationIcon = "blue"

-- Sets the duration (in milliseconds) for how long the notifications will be displayed.
-- This applies to both standard and ox_lib notifications.
Config.NotificationTime = 2000

-- Allows the anchor to break if the RPM is too high.
-- true  - The anchor can break
-- false - The anchor will not break under any conditions
Config.CanAnchorBreak = true

-- Allows passengers to drop/pick up the anchor.
-- true  - Passengers can control the anchor
-- false - Only the driver can control the anchor
Config.CanPassengerAnchor = false

-- Determines if a notification should be sent when the player tries to anchor but is not in a boat.
-- true  - Sends a notification/message when the player tries to anchor while not in a boat
-- false - Does not notify the player when not in a boat
Config.NotifyNotInBoat = false

-- Sets the maximum speed (in MPH) at which the boat can drop the anchor.
-- If the boat is moving faster than this speed, the anchor cannot be dropped.
Config.MaxSpeed = 10

-- Specifies which non-boat vehicles are allowed to drop the anchor. Boats are automatically allowed.
Config.AllowedVehicles = {
    "DODO",
}

-- Notification content
-- The notifications do not allow chat formatting.
Config.NotificationMessages = {
    "Your boat is now anchored.",        -- When the anchor is dropped.
    "Your boat is now unanchored.",      -- When the anchor is lifted.
    "You are going too fast!",           -- When the player tries to drop the anchor but is moving too fast.
    "The anchor broke!",                 -- When the anchor breaks due to high speed or RPM.
    "You are not in the driver's seat.", -- When a passenger tries to control the anchor and passengers are not allowed (depends on Config.CanPassengerAnchor).
    "You are not in a boat."             -- When the player tries to drop the anchor but is not in a boat or allowed vehicle.
}

-- Chat message content (used if Config.NotifyWith is set to "messages")
-- For more info on chat formatting, see: https://forum.cfx.re/t/chat-formatting-colors-bold-underline/67641
Config.ChatMessages = {
    "[^4Anchor^7]: Your boat is now anchored.",        -- When the anchor is dropped.
    "[^4Anchor^7]: Your boat is now unanchored.",      -- When the anchor is lifted.
    "[^4Anchor^7]: ^8You are going too fast!",         -- When the player tries to drop the anchor but is moving too fast.
    "[^4Anchor^7]: ^8The anchor broke!",               -- When the anchor breaks due to high RPM.
    "[^4Anchor^7]: You are not in the driver's seat.", -- When a passenger tries to control the anchor and is not allowed.
    "[^4Anchor^7]: ^8You are not in a boat."           -- When the player tries to drop the anchor but is not in a boat or allowed vehicle.
}